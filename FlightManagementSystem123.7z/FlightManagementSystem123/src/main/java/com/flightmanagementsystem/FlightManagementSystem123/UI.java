package com.flightmanagementsystem.FlightManagementSystem123;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.ListIterator;
import java.util.Scanner;

public class UI 
{
	public static void main(String[] args) 
	{
		BigInteger bookingId;
		int a=1,b;
		String passengername;
		int age;
		String gender;
		BigInteger phoneno;
		BigInteger idNumber;
		int noOfPassengers;
		
		Scanner s = new Scanner(System.in);
		DTO dto = new DTO();//Bean
		Service serv = new Service();
		//HashMap hm = new HashMap();
		//DAO dao = new DAO();
		while(a!=0)
		{
            System.out.println("1.addBooking");
			System.out.println("2.modifyBooking");
			System.out.println("3.viewBooking");
			System.out.println("4.viewAllBooking");
			System.out.println("5.deleteBooking");
			System.out.println("Enter Choice");
			b=s.nextInt();
			switch(b)
			{
			case 1:
				
				System.out.println("Number of Passengers");
				noOfPassengers = s.nextInt();
				dto.setNoOfPassengers(noOfPassengers);
				int i;
				for(i=1;i<=noOfPassengers;i++)
				{
				System.out.println("Enter Name");
				passengername = s.next()+s.nextLine();
				//hm.put(passengername, s.next()+s.nextLine());
				dto.setPassengername(passengername); 
				
				System.out.println("Enter Age");
				age = s.nextInt();
				dto.setAge(age);
				
				System.out.println("Gender");
				gender = s.next()+s.nextLine();
				dto.setGender(gender);
				
				System.out.println("Enter phone number");
				phoneno = s.nextBigInteger();
				dto.setPhoneno(phoneno);
				
				System.out.println("Enter Id number");
				idNumber = s.nextBigInteger();
				dto.setIdNumber(idNumber);
				} 
				int updateCount = serv.addBooking(dto);	
				System.out.println(noOfPassengers+"ticket has been succesfully booked.");
				break;
			
			case 4:
				/*System.out.println("Enter the bookingid");
				bookingId = s.nextBigInteger();*/
				/*try
				{
				ArrayList x = serv.viewAllBooking();
				
				ListIterator li=x.listIterator();
				while(li.hasNext())
					{
					System.out.println(li.next());

					}
				}
				catch(Exception e)
			    {
				   e.printStackTrace();
				}
				break;*/
				
				//System.out.println("The collection is: " + hm.values());
			}			
}}
}
