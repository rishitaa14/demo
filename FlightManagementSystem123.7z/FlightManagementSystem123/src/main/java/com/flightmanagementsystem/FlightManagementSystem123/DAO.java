package com.flightmanagementsystem.FlightManagementSystem123;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;


public class DAO {
	HashMap<BigInteger,DTO> hm = new HashMap<BigInteger,DTO>();
	//ArrayList<DTO> d = new ArrayList<DTO>();
	
	public void addBooking(DTO dto) 
	{
  //Map<BigInteger,DTO> hm = new HashMap<BigInteger,DTO>();
        hm.put(int,noOfPassengers);
        
        //d.add(dto);	
        	
    }

	public String getViewAllBooking(DTO dto) 
	{
		String value = hm.get(bookingId);
		//ListIterator li = d.listIterator();
		return value;
	  
	}

}
