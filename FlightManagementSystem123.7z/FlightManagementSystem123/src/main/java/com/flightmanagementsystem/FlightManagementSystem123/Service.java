package com.flightmanagementsystem.FlightManagementSystem123;

import java.math.BigInteger;
import java.util.ArrayList;



public class Service 
{
	//DTO dto = new DTO();
	
	public int addBooking(DTO dto) 
	{
		DAO dao = new DAO();
		/*dto.setNoOfPassengers(noOfPassengers);
		dto.setPassengername(passengername);
		dto.setAge(age);
		dto.setGender(gender);
		dto.setPhoneno(phoneno);
		dto.setIdNumber(idNumber);
	    dao.addBooking();*/
		
		int updateResult = 0;
		 try
		 {
			 updateResult = dao.addBooking(dto);
			 return updateResult;
		 }
		 catch(Exception ex)
		 {
			 System.out.println(ex.toString());
			 return 0;
		 }
	}

	public ArrayList viewAllBooking() 
	{
		  DAO dao = new DAO();
	      ArrayList result = dao.getViewAllBooking();
			 
			return result;
    }

}
